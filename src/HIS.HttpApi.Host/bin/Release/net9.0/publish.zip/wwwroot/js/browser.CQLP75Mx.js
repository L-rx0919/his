const s="/img/browser.dBySxJgS.svg";export{s as default};
