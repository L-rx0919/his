import{aS as s}from"./index.ZLNrSxa7.js";const i=i=>["",...s].includes(i);export{i};
