import{bK as o}from"./index.ZLNrSxa7.js";const a=(...a)=>r=>{a.forEach((a=>{o(a)?a(r):a.value=r}))};export{a as c};
