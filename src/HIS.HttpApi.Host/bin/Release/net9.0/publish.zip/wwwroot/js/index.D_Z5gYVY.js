import{I as e,i as o}from"./index.ZLNrSxa7.js";const r=({from:r,replacement:s,scope:i,version:m,ref:t,type:a="API"},p)=>{e((()=>o(p)),(e=>{}),{immediate:!0})};export{r as u};
