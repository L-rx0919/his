function t(t){return/^(https?:|http?:|mailto:|tel:)/.test(t)}function e(t){if(0===t)return"-";return Math.abs(100*t).toFixed(2).replace(/\.?0+$/,"")+"%"}export{e as f,t as i};
